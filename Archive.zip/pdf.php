<?php



header("Location: https://www.google.com");

















die();
$pdfUrl = "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf";

$pdfContents = file_get_contents($pdfUrl);
die($pdfContents);